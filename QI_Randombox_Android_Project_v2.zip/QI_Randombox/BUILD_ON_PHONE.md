# Build the APK using only an Android phone (GitHub Actions)

This project includes `.github/workflows/build-apk.yml` for a cloud build. You need a GitHub account and internet access. The source code will be stored in the repository you create and compiled on GitHub-hosted runners.

1. Download and extract `QI_Randombox_Android_Project.zip` on your phone.
2. In your phone browser, sign in to GitHub and create a new repository named `QI-Randombox`. For a personal project, choose **Private**.
3. Upload the extracted project files and folders to the repository. Make sure `.github/workflows/build-apk.yml` is included; hidden folders can be tricky on mobile, so verify it appears in the repository.
4. Open the repository's **Actions** tab. If prompted, enable workflows.
5. Select **Build QI Randombox APK**, tap **Run workflow**, then run it on the default branch.
6. Wait for the workflow to finish with a green check. Open that run, find **Artifacts**, and download `QI-Randombox-debug-apk`.
7. Extract the downloaded artifact ZIP to find `app-debug.apk`, then tap it to install. Android may ask you to allow installs from your browser or file manager; only enable this for the app you are using and turn it off again afterward if desired.

Notes:
- This creates a debug APK for testing, not a Play Store release.
- The build may fail if the source project has code or dependency issues. Read the failed workflow log and fix errors before retrying.
- Do not upload passwords, signing keys, API tokens, or private personal information to the repository.
