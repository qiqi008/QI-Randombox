package com.qi.randombox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

private val Ink = Color(0xFF15171D)
private val Muted = Color(0xFF777D8B)
private val Accent = Color(0xFF7165F2)
private val CanvasBg = Color(0xFFF5F6FA)
private val CardBg = Color.White

data class Prize(
    val id: Long,
    val name: String,
    val subtitle: String,
    val probability: Double,
    val color: Long,
    val stock: Int = -1
)

data class WinRecord(
    val id: Long,
    val prizeName: String,
    val method: String,
    val timestamp: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = LocalStore(this)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Accent,
                    background = CanvasBg,
                    surface = CardBg,
                    onBackground = Ink,
                    onSurface = Ink
                )
            ) {
                RandomboxApp(store)
            }
        }
    }
}

@Composable
private fun RandomboxApp(store: LocalStore) {
    var page by remember { mutableStateOf("抽奖") }
    var prizes by remember { mutableStateOf(store.loadPrizes()) }
    var records by remember { mutableStateOf(store.loadRecords()) }
    var currentWin by remember { mutableStateOf<Prize?>(null) }
    var showWinDialog by remember { mutableStateOf(false) }
    var boardColumns by remember { mutableIntStateOf(store.loadBoardColumns()) }
    var boardCardHeight by remember { mutableIntStateOf(store.loadBoardCardHeight()) }
    var boardStyle by remember { mutableStateOf(store.loadBoardStyle()) }
    var showStockOnBoard by remember { mutableStateOf(store.loadShowStock()) }
    var spinning by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var prizeName by remember { mutableStateOf("") }
    var prizeDesc by remember { mutableStateOf("") }
    var probability by remember { mutableStateOf("10") }
    var editMode by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }

    fun savePrizes() = store.savePrizes(prizes)
    fun saveRecords() = store.saveRecords(records)

    Scaffold(
        containerColor = CanvasBg,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("抽奖", "板块", "奖池", "记录").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = {
                            Text(
                                when (item) {
                                    "抽奖" -> "✦"
                                    "板块" -> "▦"
                                    "奖池" -> "◇"
                                    else -> "◷"
                                },
                                fontSize = 19.sp
                            )
                        },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("QI Randombox", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                    Text("把每一次惊喜，做成自己的活动", fontSize = 12.sp, color = Muted)
                }
                Box(
                    Modifier.size(42.dp).background(Accent, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("Q", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp) }
            }
            Spacer(Modifier.height(18.dp))
            when (page) {
                "抽奖" -> DrawPage(
                    prizes = prizes,
                    currentWin = currentWin,
                    spinning = spinning,
                    onDraw = {
                        val available = prizes.filter { it.stock != 0 && it.probability > 0 }
                        val sum = available.sumOf { it.probability }
                        if (available.isEmpty() || sum <= 0) {
                            toast = "奖池为空，请先添加奖品并设置概率"
                        } else {
                            spinning = true
                            val roll = Random.nextDouble() * sum
                            var cursor = 0.0
                            val win = available.firstOrNull {
                                cursor += it.probability
                                roll < cursor
                            } ?: available.last()
                            currentWin = win
                            showWinDialog = true
                            records = listOf(WinRecord(System.currentTimeMillis(), win.name, "板块抽奖", System.currentTimeMillis())) + records
                            val idx = prizes.indexOfFirst { it.id == win.id }
                            if (idx >= 0 && prizes[idx].stock > 0) {
                                prizes = prizes.toMutableList().also { it[idx] = it[idx].copy(stock = it[idx].stock - 1) }
                                savePrizes()
                            }
                            saveRecords()
                            spinning = false
                        }
                    },
                    onGoPrizePool = { page = "奖池" }
                )
                "板块" -> BlocksPage(
                    prizes = prizes,
                    columns = boardColumns,
                    cardHeight = boardCardHeight,
                    style = boardStyle,
                    showStock = showStockOnBoard,
                    onColumnsChange = { boardColumns = it; store.saveBoardColumns(it) },
                    onCardHeightChange = { boardCardHeight = it; store.saveBoardCardHeight(it) },
                    onStyleChange = { boardStyle = it; store.saveBoardStyle(it) },
                    onShowStockChange = { showStockOnBoard = it; store.saveShowStock(it) },
                    onDraw = { page = "抽奖" }
                )
                "奖池" -> PrizePoolPage(
                    prizes = prizes,
                    onAdd = { showAdd = true },
                    onRemove = { id ->
                        prizes = prizes.filterNot { it.id == id }
                        savePrizes()
                    },
                    onToggleEdit = { editMode = !editMode },
                    editMode = editMode,
                    onProbabilityChange = { id, value ->
                        val parsed = value.toDoubleOrNull()
                        if (parsed != null && parsed >= 0) {
                            prizes = prizes.map { if (it.id == id) it.copy(probability = parsed) else it }
                            savePrizes()
                        }
                    },
                    onStockChange = { id, value ->
                        val parsed = value.toIntOrNull()
                        if (parsed != null && parsed >= -1) {
                            prizes = prizes.map { if (it.id == id) it.copy(stock = parsed) else it }
                            savePrizes()
                        }
                    }
                )
                "记录" -> RecordsPage(records, onClear = {
                    records = emptyList()
                    saveRecords()
                })
            }
        }
    }

    if (showWinDialog && currentWin != null) {
        val win = currentWin!!
        AlertDialog(
            onDismissRequest = { showWinDialog = false },
            icon = { Text("🎉", fontSize = 38.sp) },
            title = { Text("恭喜获得！", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        Modifier.fillMaxWidth().background(Color(win.color), RoundedCornerShape(18.dp)).padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("✦", color = Color(0xFF4E4A66), fontSize = 34.sp)
                            Text(win.name, color = Color(0xFF232330), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                            if (win.subtitle.isNotBlank()) Text(win.subtitle, color = Color(0xFF555365), fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("中奖结果已自动保存到记录", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = { Button(onClick = { showWinDialog = false }) { Text("太棒了") } },
            dismissButton = { TextButton(onClick = { showWinDialog = false; page = "记录" }) { Text("查看记录") } }
        )
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("添加奖品") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(prizeName, { prizeName = it }, label = { Text("奖品名称") }, singleLine = true)
                    OutlinedTextField(prizeDesc, { prizeDesc = it }, label = { Text("描述（可选）") }, singleLine = true)
                    OutlinedTextField(probability, { probability = it }, label = { Text("权重 / 概率") }, singleLine = true)
                    Text("数值越大，抽中相对机会越高。库存 -1 表示不限量。", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = probability.toDoubleOrNull()
                    if (prizeName.isNotBlank() && p != null && p >= 0) {
                        val palette = listOf(0xFFE8E4FF, 0xFFFFE9D8, 0xFFDDF5EB, 0xFFDDEBFF, 0xFFFFE2EA)
                        prizes = prizes + Prize(System.nanoTime(), prizeName.trim(), prizeDesc.trim(), p, palette[prizes.size % palette.size])
                        savePrizes()
                        prizeName = ""; prizeDesc = ""; probability = "10"
                        showAdd = false
                    }
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("取消") } }
        )
    }
    if (toast.isNotBlank()) {
        AlertDialog(onDismissRequest = { toast = "" }, confirmButton = {
            TextButton(onClick = { toast = "" }) { Text("知道了") }
        }, text = { Text(toast) })
    }
}

@Composable
private fun DrawPage(
    prizes: List<Prize>,
    currentWin: Prize?,
    spinning: Boolean,
    onDraw: () -> Unit,
    onGoPrizePool: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("今日活动", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("板块式抽奖 · 本地保存", fontSize = 12.sp, color = Muted)
            }
            Surface(color = Color(0xFFEAE8FF), shape = RoundedCornerShape(30.dp)) {
                Text("本地模式", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Accent, fontSize = 11.sp)
            }
        }
        if (prizes.isEmpty()) {
            Surface(shape = RoundedCornerShape(24.dp), color = CardBg) {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("◇", color = Accent, fontSize = 42.sp)
                    Text("先装满你的奖池", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("添加奖品后，即可开始抽奖", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onGoPrizePool) { Text("添加奖品") }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f, fill = false),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Surface(shape = RoundedCornerShape(24.dp), color = Color(0xFF171923)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("LUCKY MOMENT", color = Color(0xFFBEB8FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("好运正在加载", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("奖品由概率权重决定，动画不影响抽奖结果", color = Color(0xFFB4B8C6), fontSize = 12.sp)
                            Spacer(Modifier.height(18.dp))
                            PrizeBlockGrid(prizes.take(6))
                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = onDraw,
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                enabled = !spinning
                            ) { Text(if (spinning) "抽取中…" else "开始抽奖", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
        Text("奖池概览", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("奖品种类", prizes.size.toString(), Modifier.weight(1f))
            StatCard("可抽奖品", prizes.count { it.stock != 0 }.toString(), Modifier.weight(1f))
            StatCard("中奖记录", "已自动保存", Modifier.weight(1f))
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun BlocksPage(
    prizes: List<Prize>,
    columns: Int,
    cardHeight: Int,
    style: String,
    showStock: Boolean,
    onColumnsChange: (Int) -> Unit,
    onCardHeightChange: (Int) -> Unit,
    onStyleChange: (String) -> Unit,
    onShowStockChange: (Boolean) -> Unit,
    onDraw: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("板块布局", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("自定义活动板块 · 设置会自动保存", color = Muted, fontSize = 12.sp)
                }
                Surface(color = Color(0xFFEAE8FF), shape = RoundedCornerShape(30.dp)) {
                    Text("可编辑", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Accent, fontSize = 11.sp)
                }
            }
        }
        item {
            Surface(color = if (style == "深色") Color(0xFF171923) else Color.White, shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("SPECIAL DROP", color = if (style == "深色") Color(0xFFBEB8FF) else Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("限定奖励中心", color = if (style == "深色") Color.White else Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Text("每一次随机选择，都可能有惊喜", color = if (style == "深色") Color(0xFFB4B8C6) else Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    PrizeBlockGrid(prizes, columns, cardHeight, showStock, style)
                    Spacer(Modifier.height(12.dp))
                    Text("布局预览 · ${prizes.size} 个奖品板块", color = if (style == "深色") Color(0xFFB4B8C6) else Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            Surface(color = CardBg, shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("布局设置", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("每行板块数量", color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1, 2, 3).forEach { count ->
                            if (columns == count) Button(onClick = { onColumnsChange(count) }, modifier = Modifier.weight(1f)) { Text("${count}列") }
                            else OutlinedButton(onClick = { onColumnsChange(count) }, modifier = Modifier.weight(1f)) { Text("${count}列") }
                        }
                    }
                    Text("板块大小", color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(84, 112, 140).forEachIndexed { index, height ->
                            val label = listOf("紧凑", "标准", "宽松")[index]
                            if (cardHeight == height) Button(onClick = { onCardHeightChange(height) }, modifier = Modifier.weight(1f)) { Text(label) }
                            else OutlinedButton(onClick = { onCardHeightChange(height) }, modifier = Modifier.weight(1f)) { Text(label) }
                        }
                    }
                    Text("板块主题", color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("深色", "浅色").forEach { option ->
                            if (style == option) Button(onClick = { onStyleChange(option) }, modifier = Modifier.weight(1f)) { Text(option) }
                            else OutlinedButton(onClick = { onStyleChange(option) }, modifier = Modifier.weight(1f)) { Text(option) }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("显示库存信息", fontWeight = FontWeight.Medium)
                            Text("在每个奖品板块显示剩余库存", color = Muted, fontSize = 11.sp)
                        }
                        Switch(checked = showStock, onCheckedChange = onShowStockChange)
                    }
                }
            }
        }
        item { Button(onClick = onDraw, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("前往抽奖", fontSize = 16.sp) } }
    }
}

@Composable
private fun PrizeBlockGrid(prizes: List<Prize>, columns: Int = 2, cardHeight: Int = 92, showStock: Boolean = true, style: String = "深色") {
    if (prizes.isEmpty()) {
        Box(Modifier.fillMaxWidth().height(110.dp), contentAlignment = Alignment.Center) {
            Text("还没有奖品", color = if (style == "深色") Color(0xFFB4B8C6) else Muted)
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            prizes.chunked(columns.coerceIn(1, 3)).forEach { rowPrizes ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowPrizes.forEach { prize ->
                        Surface(
                            modifier = Modifier.weight(1f).height(cardHeight.dp),
                            color = Color(prize.color),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Text("✦", color = Color(0xFF4E4A66), fontSize = if (cardHeight <= 84) 16.sp else 19.sp)
                                Column {
                                    Text(prize.name, color = Color(0xFF232330), fontWeight = FontWeight.Bold, maxLines = if (cardHeight >= 130) 2 else 1, overflow = TextOverflow.Ellipsis)
                                    if (showStock) Text(if (prize.stock == -1) "不限量" else "库存 ${prize.stock}", color = Color(0xFF555365), fontSize = 10.sp)
                                }
                            }
                        }
                    }
                    repeat((columns.coerceIn(1, 3) - rowPrizes.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun PrizePoolPage(
    prizes: List<Prize>,
    onAdd: () -> Unit,
    onRemove: (Long) -> Unit,
    onToggleEdit: () -> Unit,
    editMode: Boolean,
    onProbabilityChange: (Long, String) -> Unit,
    onStockChange: (Long, String) -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("奖池管理", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("设置奖品、权重和库存", color = Muted, fontSize = 12.sp)
            }
            TextButton(onClick = onToggleEdit) { Text(if (editMode) "完成" else "编辑") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAdd, modifier = Modifier.weight(1f)) { Text("＋ 添加奖品") }
            OutlinedButton(onClick = onToggleEdit, modifier = Modifier.weight(1f)) { Text(if (editMode) "收起设置" else "概率/库存") }
        }
        if (prizes.isEmpty()) {
            Surface(color = CardBg, shape = RoundedCornerShape(18.dp)) {
                Text("奖池还是空的，添加第一个奖品吧。", Modifier.padding(20.dp), color = Muted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(prizes, key = { it.id }) { prize ->
                    Surface(color = CardBg, shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).background(Color(prize.color), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                    Text("✦", fontSize = 20.sp)
                                }
                                Spacer(Modifier.width(11.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(prize.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(if (prize.subtitle.isBlank()) "普通奖品" else prize.subtitle, color = Muted, fontSize = 12.sp)
                                }
                                TextButton(onClick = { onRemove(prize.id) }) { Text("删除", color = Color(0xFFD34C5B)) }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("权重 ${prize.probability}", color = Muted, fontSize = 12.sp)
                                Spacer(Modifier.weight(1f))
                                Text(if (prize.stock == -1) "不限量" else "库存 ${prize.stock}", color = Muted, fontSize = 12.sp)
                            }
                            AnimatedVisibility(editMode) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    var prob by remember(prize.id, prize.probability) { mutableStateOf(prize.probability.toString()) }
                                    var stock by remember(prize.id, prize.stock) { mutableStateOf(prize.stock.toString()) }
                                    OutlinedTextField(prob, { prob = it }, modifier = Modifier.weight(1f), label = { Text("权重") }, singleLine = true)
                                    OutlinedTextField(stock, { stock = it }, modifier = Modifier.weight(1f), label = { Text("库存(-1不限)") }, singleLine = true)
                                    IconButton(onClick = {
                                        onProbabilityChange(prize.id, prob)
                                        onStockChange(prize.id, stock)
                                    }) { Text("✓", color = Accent) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordsPage(records: List<WinRecord>, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("中奖记录", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("每次正式抽奖后自动保存", color = Muted, fontSize = 12.sp)
            }
            if (records.isNotEmpty()) TextButton(onClick = onClear) { Text("清空记录", color = Color(0xFFD34C5B)) }
        }
        if (records.isEmpty()) {
            Surface(color = CardBg, shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("◷", fontSize = 38.sp, color = Accent)
                    Text("还没有中奖记录", fontWeight = FontWeight.Bold)
                    Text("抽奖结果会自动保存在这台设备上", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(records, key = { it.id }) { record ->
                    Surface(color = CardBg, shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).background(Color(0xFFECEAFF), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                Text("✦", color = Accent, fontSize = 20.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(record.prizeName, fontWeight = FontWeight.Bold)
                                Text(record.method, color = Muted, fontSize = 12.sp)
                            }
                            Text(formatTime(record.timestamp), color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = CardBg, shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun formatTime(timestamp: Long): String =
    SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(timestamp))

private class LocalStore(context: android.content.Context) {
    private val prefs = context.getSharedPreferences("qi_randombox_local", android.content.Context.MODE_PRIVATE)

    fun loadBoardColumns(): Int = prefs.getInt("board_columns", 2).coerceIn(1, 3)
    fun saveBoardColumns(value: Int) { prefs.edit().putInt("board_columns", value.coerceIn(1, 3)).apply() }
    fun loadBoardCardHeight(): Int = prefs.getInt("board_card_height", 112).let { if (it in listOf(84, 112, 140)) it else 112 }
    fun saveBoardCardHeight(value: Int) { prefs.edit().putInt("board_card_height", value).apply() }
    fun loadBoardStyle(): String = prefs.getString("board_style", "深色") ?: "深色"
    fun saveBoardStyle(value: String) { prefs.edit().putString("board_style", value).apply() }
    fun loadShowStock(): Boolean = prefs.getBoolean("board_show_stock", true)
    fun saveShowStock(value: Boolean) { prefs.edit().putBoolean("board_show_stock", value).apply() }

    fun loadPrizes(): List<Prize> {
        val raw = prefs.getString("prizes", null) ?: return listOf(
            Prize(1, "限定礼盒", "惊喜奖励", 50.0, 0xFFE8E4FF),
            Prize(2, "稀有徽章", "收藏纪念", 30.0, 0xFFFFE9D8),
            Prize(3, "幸运补给", "实用好礼", 19.0, 0xFFDDF5EB),
            Prize(4, "隐藏大奖", "超稀有奖励", 1.0, 0xFFFFE2EA)
        ).also { savePrizes(it) }
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Prize(o.getLong("id"), o.getString("name"), o.optString("subtitle"),
                    o.getDouble("probability"), o.getLong("color"), o.optInt("stock", -1))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun savePrizes(prizes: List<Prize>) {
        val arr = JSONArray()
        prizes.forEach { p ->
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("subtitle", p.subtitle)
                .put("probability", p.probability).put("color", p.color).put("stock", p.stock))
        }
        prefs.edit().putString("prizes", arr.toString()).apply()
    }

    fun loadRecords(): List<WinRecord> {
        val raw = prefs.getString("records", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                WinRecord(o.getLong("id"), o.getString("prizeName"), o.getString("method"), o.getLong("timestamp"))
            }.sortedByDescending { it.timestamp }
        } catch (_: Exception) { emptyList() }
    }

    fun saveRecords(records: List<WinRecord>) {
        val arr = JSONArray()
        records.forEach { r ->
            arr.put(JSONObject().put("id", r.id).put("prizeName", r.prizeName)
                .put("method", r.method).put("timestamp", r.timestamp))
        }
        prefs.edit().putString("records", arr.toString()).apply()
    }
}
