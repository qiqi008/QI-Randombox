# QI Randombox

QI Randombox is an Android-native starter app for creating and running local lottery activities.

## Current starter features
- Minimal, responsive Material 3 interface
- Block-based prize board inspired by game event lobbies
- Local prize pool management
- Weighted random draws with decimal weights
- Optional finite inventory (`-1` means unlimited)
- Automatically persisted win history
- Local storage; no account or server required
- Phone/tablet and portrait/landscape layouts use responsive Compose layout primitives

## Android compatibility
- `minSdk = 23` (Android 6.0 and newer)
- `compileSdk = 36`, `targetSdk = 36`
- Java/Kotlin target 17
- Build with Android Studio and a compatible Android SDK 36 installation

Android platform support can vary by device vendor and system image. Build and test on the specific Android versions/devices you intend to support before release.

## Build
1. Open this folder in Android Studio.
2. Install Android SDK Platform 36 and a compatible Android Gradle Plugin toolchain when prompted.
3. Allow Gradle sync to finish.
4. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Important current limitations
This is a working starter project, not yet the complete visual activity editor originally planned. The current block page previews prize cards but does not yet support drag/resize, imported images, custom fonts, animation timelines, audio tracks, project archive import/export, or high-resolution image export. The result log currently records prize name, draw mode, and time. These can be added in subsequent iterations.

## Local data note
Data is stored in app-private preferences. Android normally removes app-private data when the app is uninstalled; use a future export/backup feature before uninstalling or changing devices.
